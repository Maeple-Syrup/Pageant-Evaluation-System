<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();

class CommentHandler {
    private $db;
    private $judgeId;
    private $message = '';
    private $messageType = '';
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
    }
    
    public function addComment($contestantId, $commentText) {
        if (empty(trim($commentText))) {
            $this->message = "Comment cannot be empty.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("
            INSERT INTO comments (judge_id, contestant_id, comment_text) 
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iis", $this->judgeId, $contestantId, $commentText);
        
        if ($stmt->execute()) {
            $this->message = "Comment added successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error adding comment.";
        $this->messageType = 'error';
        return false;
    }
    
    public function updateComment($commentId, $commentText) {
        if (empty(trim($commentText))) {
            $this->message = "Comment cannot be empty.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE comments 
            SET comment_text = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = ? AND judge_id = ?
        ");
        $stmt->bind_param("sii", $commentText, $commentId, $this->judgeId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $this->message = "Comment updated successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error updating comment.";
        $this->messageType = 'error';
        return false;
    }
    
    public function deleteComment($commentId) {
        $stmt = $this->db->prepare("DELETE FROM comments WHERE id = ? AND judge_id = ?");
        $stmt->bind_param("ii", $commentId, $this->judgeId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $this->message = "Comment deleted successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error deleting comment.";
        $this->messageType = 'error';
        return false;
    }
    
    public function getMessage() {
        return $this->message;
    }
    
    public function getMessageType() {
        return $this->messageType;
    }
}

class CommentData {
    private $db;
    private $judgeId;
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
    }
    
    public function getMyComments() {
        $stmt = $this->db->prepare("
            SELECT 
                cm.id,
                cm.comment_text,
                cm.created_at,
                cm.updated_at,
                c.contestant_number,
                c.full_name as contestant_name
            FROM comments cm
            JOIN contestants c ON cm.contestant_id = c.id
            WHERE cm.judge_id = ?
            ORDER BY cm.created_at DESC
        ");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        return $stmt->get_result();
    }
    
    public function getComment($commentId) {
        $stmt = $this->db->prepare("
            SELECT * FROM comments 
            WHERE id = ? AND judge_id = ?
        ");
        $stmt->bind_param("ii", $commentId, $this->judgeId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0 ? $result->fetch_assoc() : null;
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');
$commentHandler = new CommentHandler($db, $judgeId);
$commentData = new CommentData($db, $judgeId);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_comment') {
            $commentHandler->addComment($_POST['contestant_id'], $_POST['comment_text']);
        } elseif ($_POST['action'] === 'update_comment') {
            $commentHandler->updateComment($_POST['comment_id'], $_POST['comment_text']);
        } elseif ($_POST['action'] === 'delete_comment') {
            $commentHandler->deleteComment($_POST['comment_id']);
        }
    }
}

// Get comment for editing
$editComment = null;
if (isset($_GET['edit'])) {
    $editComment = $commentData->getComment($_GET['edit']);
}

$contestants = $db->query("SELECT id, contestant_number, full_name FROM contestants ORDER BY contestant_number");
$myComments = $commentData->getMyComments();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
    <link rel="stylesheet" href="../Style/comments.css">
</head>
<body>
    
    
    <div class="container">
        <div class="page-header">
            <h1>💬 Comments</h1>
            <p>Add feedback for contestants</p>
        </div>
        
        <?php if ($commentHandler->getMessage()): ?>
            <div class="message <?php echo $commentHandler->getMessageType(); ?>">
                <?php echo htmlspecialchars($commentHandler->getMessage()); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2><?php echo $editComment ? 'Edit Comment' : 'Add Comment'; ?></h2>
            <form method="POST" action="" class="comment-form">
                <input type="hidden" name="action" value="<?php echo $editComment ? 'update_comment' : 'add_comment'; ?>">
                <?php if ($editComment): ?>
                    <input type="hidden" name="comment_id" value="<?php echo $editComment['id']; ?>">
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="contestant_id">Contestant</label>
                    <select id="contestant_id" name="contestant_id" required <?php echo $editComment ? 'disabled' : ''; ?>>
                        <option value="">Select Contestant</option>
                        <?php while ($contestant = $contestants->fetch_assoc()): ?>
                            <option value="<?php echo $contestant['id']; ?>" 
                                <?php echo ($editComment && $editComment['contestant_id'] == $contestant['id']) ? 'selected' : ''; ?>>
                                #<?php echo $contestant['contestant_number']; ?> - <?php echo htmlspecialchars($contestant['full_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="comment_text">Comment</label>
                    <textarea id="comment_text" name="comment_text" rows="5" required placeholder="Enter your feedback here..."><?php echo $editComment ? htmlspecialchars($editComment['comment_text']) : ''; ?></textarea>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn-primary">
                        <?php echo $editComment ? 'Update Comment' : 'Add Comment'; ?>
                    </button>
                    <?php if ($editComment): ?>
                        <a href="comments.php" class="btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>My Comments</h2>
            <?php if ($myComments->num_rows > 0): ?>
                <div class="comments-list">
                    <?php while ($row = $myComments->fetch_assoc()): ?>
                        <div class="comment-item">
                            <div class="comment-header">
                                <div class="comment-contestant">
                                    <strong>#<?php echo $row['contestant_number']; ?> - <?php echo htmlspecialchars($row['contestant_name']); ?></strong>
                                </div>
                                <div class="comment-date">
                                    <?php echo date('M d, Y H:i', strtotime($row['created_at'])); ?>
                                    <?php if ($row['created_at'] != $row['updated_at']): ?>
                                        <span class="updated-badge">(edited)</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="comment-text">
                                <?php echo nl2br(htmlspecialchars($row['comment_text'])); ?>
                            </div>
                            <div class="comment-actions">
                                <a href="?edit=<?php echo $row['id']; ?>" class="btn-edit">Edit</a>
                                <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Delete this comment?');">
                                    <input type="hidden" name="action" value="delete_comment">
                                    <input type="hidden" name="comment_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn-delete">Delete</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="empty-state">No comments added yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>