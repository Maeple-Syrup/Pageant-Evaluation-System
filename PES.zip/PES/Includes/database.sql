
-- Judges table
CREATE TABLE judges (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contestants table
CREATE TABLE contestants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    contestant_number INT UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    photo_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL,
    description TEXT,
    max_score INT DEFAULT 100,
    weight DECIMAL(5,2) DEFAULT 1.00,
    display_order INT DEFAULT 0
);

-- Scores table
CREATE TABLE scores (
    id INT PRIMARY KEY AUTO_INCREMENT,
    judge_id INT NOT NULL,
    contestant_id INT NOT NULL,
    category_id INT NOT NULL,
    score DECIMAL(5,2) NOT NULL,
    scored_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (judge_id) REFERENCES judges(id) ON DELETE CASCADE,
    FOREIGN KEY (contestant_id) REFERENCES contestants(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE KEY unique_score (judge_id, contestant_id, category_id)
);

-- Comments table
CREATE TABLE comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    judge_id INT NOT NULL,
    contestant_id INT NOT NULL,
    comment_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (judge_id) REFERENCES judges(id) ON DELETE CASCADE,
    FOREIGN KEY (contestant_id) REFERENCES contestants(id) ON DELETE CASCADE
);

-- Insert default admin judge
INSERT INTO judges (username, password, full_name, email) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin Judge', 'admin@pageant.com'),
('judge1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Judge One', 'judge1@pageant.com'),
('judge2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Judge Two', 'judge2@pageant.com');
-- Default password for all: 'password'

-- Insert sample contestants
INSERT INTO contestants (contestant_number, full_name, age) VALUES
(1, 'Sarah Johnson', 22),
(2, 'Maria Garcia', 24),
(3, 'Emily Chen', 21),
(4, 'Jessica Williams', 23),
(5, 'Ashley Brown', 25);

-- Insert categories
INSERT INTO categories (category_name, description, max_score, weight, display_order) VALUES
('Beauty', 'Physical appearance and presentation', 100, 1.00, 1),
('Intelligence', 'Q&A and articulation skills', 100, 1.00, 2),
('Talent', 'Performance and creativity', 100, 1.00, 3),
('Evening Gown', 'Elegance and poise', 100, 1.00, 4),
('Personality', 'Charm and character', 100, 1.00, 5);

-- Create indexes for better performance
CREATE INDEX idx_scores_judge ON scores(judge_id);
CREATE INDEX idx_scores_contestant ON scores(contestant_id);
CREATE INDEX idx_comments_judge ON comments(judge_id);
CREATE INDEX idx_comments_contestant ON comments(contestant_id);