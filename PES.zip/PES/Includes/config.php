<?php

/* ---------- path helpers ---------- */
define('ROOT',       __DIR__ . '/..');          // points to PES
define('INCLUDES',   ROOT . '/Includes');
define('STYLE',      ROOT . '/Style');
define('ADMIN',      ROOT . '/Admin');
define('JUDGES',     ROOT . '/Judges');

// rest of your existing code (class Database, functions, etc.)

class Database {

    private $host = 'sql305.infinityfree.com';  // Your InfinityFree hostname

    private $user = 'if0_40679005';              // Your database username

    private $pass = 'XNl0yWP1xhdmE';    // The password you set

    private $name = 'if0_40679005_db_onlinepageant';  // Your database name
    private $conn;
    
    public function getConnection() {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->name);
        
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
        
        return $this->conn;
    }
}

function getDBConnection() {
    $database = new Database();
    return $database->getConnection();
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['judge_id']) && isset($_SESSION['username']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /PES/login.php');
        exit();
    }
}

function getCurrentJudge() {
    if (!isLoggedIn()) {
        return null;
    }
    
    return [
        'judge_id' => $_SESSION['judge_id'],
        'username' => $_SESSION['username'],
        'full_name' => $_SESSION['full_name'],
        'is_admin' => $_SESSION['is_admin'] ?? false
    ];
}

// NEW: Check if current user is admin
function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

// NEW: Require admin access
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: /PES/Judges/dashboard.php');
        exit();
    }
}

/* ---------- make $sessionManager available everywhere ---------- */
require_once __DIR__ . '/SessionManager.php';
$sessionManager = new SessionManager();
?>