<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();

class ContestantManager {
    private $db;
    private $message = '';
    private $messageType = '';
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function addContestant($contestantNumber, $fullName, $age, $photoUrl = '') {
        if (empty(trim($fullName))) {
            $this->message = "Contestant name is required.";
            $this->messageType = 'error';
            return false;
        }
        
        if ($age <= 0) {
            $this->message = "Age must be greater than 0.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if contestant number already exists
        $stmt = $this->db->prepare("SELECT id FROM contestants WHERE contestant_number = ?");
        $stmt->bind_param("i", $contestantNumber);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->message = "Contestant number already exists. Please use a different number.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("
            INSERT INTO contestants (contestant_number, full_name, age, photo_url) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("isis", $contestantNumber, $fullName, $age, $photoUrl);
        
        if ($stmt->execute()) {
            $this->message = "Contestant added successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error adding contestant.";
        $this->messageType = 'error';
        return false;
    }
    
    public function updateContestant($contestantId, $contestantNumber, $fullName, $age, $photoUrl = '') {
        if (empty(trim($fullName))) {
            $this->message = "Contestant name is required.";
            $this->messageType = 'error';
            return false;
        }
        
        if ($age <= 0) {
            $this->message = "Age must be greater than 0.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if contestant number exists for another contestant
        $stmt = $this->db->prepare("SELECT id FROM contestants WHERE contestant_number = ? AND id != ?");
        $stmt->bind_param("ii", $contestantNumber, $contestantId);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->message = "Contestant number already exists. Please use a different number.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE contestants 
            SET contestant_number = ?, full_name = ?, age = ?, photo_url = ?
            WHERE id = ?
        ");
        $stmt->bind_param("isisi", $contestantNumber, $fullName, $age, $photoUrl, $contestantId);
        
        if ($stmt->execute()) {
            $this->message = "Contestant updated successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error updating contestant.";
        $this->messageType = 'error';
        return false;
    }
    
    public function deleteContestant($contestantId) {
        // Check if contestant has scores
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM scores WHERE contestant_id = ?");
        $stmt->bind_param("i", $contestantId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result['count'] > 0) {
            $this->message = "Cannot delete contestant with existing scores. Delete scores first.";
            $this->messageType = 'error';
            return false;
        }
        
        // Delete comments first
        $stmt = $this->db->prepare("DELETE FROM comments WHERE contestant_id = ?");
        $stmt->bind_param("i", $contestantId);
        $stmt->execute();
        
        // Delete contestant
        $stmt = $this->db->prepare("DELETE FROM contestants WHERE id = ?");
        $stmt->bind_param("i", $contestantId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $this->message = "Contestant deleted successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error deleting contestant.";
        $this->messageType = 'error';
        return false;
    }
    
    public function getContestant($contestantId) {
        $stmt = $this->db->prepare("SELECT * FROM contestants WHERE id = ?");
        $stmt->bind_param("i", $contestantId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0 ? $result->fetch_assoc() : null;
    }
    
    public function getAllContestants() {
        return $this->db->query("SELECT * FROM contestants ORDER BY contestant_number");
    }
    
    public function getContestantStats($contestantId) {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(DISTINCT s.judge_id) as judges_count,
                COUNT(s.id) as scores_count,
                AVG(s.score) as avg_score
            FROM contestants c
            LEFT JOIN scores s ON c.id = s.contestant_id
            WHERE c.id = ?
            GROUP BY c.id
        ");
        $stmt->bind_param("i", $contestantId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0 ? $result->fetch_assoc() : ['judges_count' => 0, 'scores_count' => 0, 'avg_score' => 0];
    }
    
    public function getMessage() {
        return $this->message;
    }
    
    public function getMessageType() {
        return $this->messageType;
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');

$contestantManager = new ContestantManager($db);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_contestant') {
            $contestantManager->addContestant(
                $_POST['contestant_number'],
                $_POST['full_name'],
                $_POST['age'],
                $_POST['photo_url']
            );
        } elseif ($_POST['action'] === 'update_contestant') {
            $contestantManager->updateContestant(
                $_POST['contestant_id'],
                $_POST['contestant_number'],
                $_POST['full_name'],
                $_POST['age'],
                $_POST['photo_url']
            );
        } elseif ($_POST['action'] === 'delete_contestant') {
            $contestantManager->deleteContestant($_POST['contestant_id']);
        }
    }
}

// Get contestant for editing
$editContestant = null;
if (isset($_GET['edit'])) {
    $editContestant = $contestantManager->getContestant($_GET['edit']);
}

$contestants = $contestantManager->getAllContestants();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contestants - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
    <link rel="stylesheet" href="../Style/contestants.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>👥 Manage Contestants</h1>
            <p>Add, edit, or delete pageant contestants</p>
        </div>
        
        <?php if ($contestantManager->getMessage()): ?>
            <div class="message <?php echo $contestantManager->getMessageType(); ?>">
                <?php echo htmlspecialchars($contestantManager->getMessage()); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2><?php echo $editContestant ? 'Edit Contestant' : 'Add New Contestant'; ?></h2>
            <form method="POST" action="" class="contestant-form">
                <input type="hidden" name="action" value="<?php echo $editContestant ? 'update_contestant' : 'add_contestant'; ?>">
                <?php if ($editContestant): ?>
                    <input type="hidden" name="contestant_id" value="<?php echo $editContestant['id']; ?>">
                <?php endif; ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="contestant_number">Contestant Number *</label>
                        <input type="number" id="contestant_number" name="contestant_number" 
                               value="<?php echo $editContestant ? $editContestant['contestant_number'] : ''; ?>" 
                               min="1" step="1" placeholder="e.g., 1, 2, 3..." required>
                        <small class="form-hint">Must be unique</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="age">Age *</label>
                        <input type="number" id="age" name="age" 
                               value="<?php echo $editContestant ? $editContestant['age'] : ''; ?>" 
                               min="1" max="150" step="1" placeholder="e.g., 22" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" 
                           value="<?php echo $editContestant ? htmlspecialchars($editContestant['full_name']) : ''; ?>" 
                           placeholder="e.g., Sarah Johnson" required>
                </div>
                
                <div class="form-group">
                    <label for="photo_url">Photo URL (Optional)</label>
                    <input type="url" id="photo_url" name="photo_url" 
                           value="<?php echo $editContestant ? htmlspecialchars($editContestant['photo_url']) : ''; ?>" 
                           placeholder="https://example.com/photo.jpg">
                    <small class="form-hint">Link to contestant's photo</small>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn-primary">
                        <?php echo $editContestant ? '💾 Update Contestant' : '➕ Add Contestant'; ?>
                    </button>
                    <?php if ($editContestant): ?>
                        <a href="contestants.php" class="btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>All Contestants</h2>
            <?php if ($contestants->num_rows > 0): ?>
                <div class="contestants-grid">
                    <?php while ($contestant = $contestants->fetch_assoc()): ?>
                        <?php $stats = $contestantManager->getContestantStats($contestant['id']); ?>
                        <div class="contestant-item">
                            <div class="contestant-number-badge">#{<?php echo $contestant['contestant_number']; ?>}</div>
                            
                            <?php if ($contestant['photo_url']): ?>
                                <div class="contestant-photo">
                                    <img src="<?php echo htmlspecialchars($contestant['photo_url']); ?>" 
                                         alt="<?php echo htmlspecialchars($contestant['full_name']); ?>">
                                </div>
                            <?php else: ?>
                                <div class="contestant-photo-placeholder">
                                    👤
                                </div>
                            <?php endif; ?>
                            
                            <h3><?php echo htmlspecialchars($contestant['full_name']); ?></h3>
                            <p class="contestant-age">Age: <?php echo $contestant['age']; ?></p>
                            
                            <div class="contestant-stats">
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo $stats['judges_count']; ?></span>
                                    <span class="stat-text">Judges</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo $stats['scores_count']; ?></span>
                                    <span class="stat-text">Scores</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo $stats['avg_score'] ? number_format($stats['avg_score'], 1) : 'N/A'; ?></span>
                                    <span class="stat-text">Avg</span>
                                </div>
                            </div>
                            
                            <div class="contestant-actions">
                                <a href="?edit=<?php echo $contestant['id']; ?>" class="btn-edit">✏️ Edit</a>
                                <form method="POST" action="" style="display: inline;" 
                                      onsubmit="return confirm('Delete this contestant? This cannot be undone if there are no scores.');">
                                    <input type="hidden" name="action" value="delete_contestant">
                                    <input type="hidden" name="contestant_id" value="<?php echo $contestant['id']; ?>">
                                    <button type="submit" class="btn-delete">🗑️ Delete</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="empty-state">No contestants yet. Add your first contestant above!</p>
            <?php endif; ?>
        </div>
        
        <div class="card info-card">
            <h3>💡 Tips for Managing Contestants</h3>
            <ul>
                <li><strong>Contestant Number:</strong> Must be unique (e.g., 1, 2, 3, or use creative numbers like 101, 102)</li>
                <li><strong>Photo URL:</strong> Optional, but makes the system look better. Use image hosting services like Imgur</li>
                <li><strong>Cannot Delete:</strong> Contestants with scores cannot be deleted (protects your data)</li>
                <li><strong>Bulk Add:</strong> Add contestants one by one, or import them via SQL if you have many</li>
            </ul>
        </div>
    </div>
</body>
</html>