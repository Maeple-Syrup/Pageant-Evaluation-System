<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();

class JudgeManager {
    private $db;
    private $message = '';
    private $messageType = '';
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function addJudge($username, $password, $fullName, $email) {
        if (empty(trim($username)) || empty(trim($password)) || empty(trim($fullName)) || empty(trim($email))) {
            $this->message = "All fields are required.";
            $this->messageType = 'error';
            return false;
        }
        
        if (strlen($password) < 6) {
            $this->message = "Password must be at least 6 characters long.";
            $this->messageType = 'error';
            return false;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->message = "Invalid email format.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if username already exists
        $stmt = $this->db->prepare("SELECT id FROM judges WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->message = "Username already exists. Please use a different username.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if email already exists
        $stmt = $this->db->prepare("SELECT id FROM judges WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->message = "Email already exists. Please use a different email.";
            $this->messageType = 'error';
            return false;
        }
        
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $this->db->prepare("
            INSERT INTO judges (username, password, full_name, email) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("ssss", $username, $hashedPassword, $fullName, $email);
        
        if ($stmt->execute()) {
            $this->message = "Judge added successfully! Username: $username, Password: $password";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error adding judge.";
        $this->messageType = 'error';
        return false;
    }
    
    public function updateJudge($judgeId, $username, $fullName, $email, $newPassword = '') {
        if (empty(trim($username)) || empty(trim($fullName)) || empty(trim($email))) {
            $this->message = "Username, full name, and email are required.";
            $this->messageType = 'error';
            return false;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->message = "Invalid email format.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if username exists for another judge
        $stmt = $this->db->prepare("SELECT id FROM judges WHERE username = ? AND id != ?");
        $stmt->bind_param("si", $username, $judgeId);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->message = "Username already exists. Please use a different username.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if email exists for another judge
        $stmt = $this->db->prepare("SELECT id FROM judges WHERE email = ? AND id != ?");
        $stmt->bind_param("si", $email, $judgeId);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->message = "Email already exists. Please use a different email.";
            $this->messageType = 'error';
            return false;
        }
        
        // Update with or without password change
        if (!empty($newPassword)) {
            if (strlen($newPassword) < 6) {
                $this->message = "Password must be at least 6 characters long.";
                $this->messageType = 'error';
                return false;
            }
            
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("
                UPDATE judges 
                SET username = ?, password = ?, full_name = ?, email = ?
                WHERE id = ?
            ");
            $stmt->bind_param("ssssi", $username, $hashedPassword, $fullName, $email, $judgeId);
        } else {
            $stmt = $this->db->prepare("
                UPDATE judges 
                SET username = ?, full_name = ?, email = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sssi", $username, $fullName, $email, $judgeId);
        }
        
        if ($stmt->execute()) {
            $this->message = "Judge updated successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error updating judge.";
        $this->messageType = 'error';
        return false;
    }
    
    public function deleteJudge($judgeId, $currentJudgeId) {
        if ($judgeId == $currentJudgeId) {
            $this->message = "You cannot delete your own account.";
            $this->messageType = 'error';
            return false;
        }
        
        // Check if judge has scores
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM scores WHERE judge_id = ?");
        $stmt->bind_param("i", $judgeId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result['count'] > 0) {
            $this->message = "Cannot delete judge with existing scores. Delete scores first.";
            $this->messageType = 'error';
            return false;
        }
        
        // Delete comments first
        $stmt = $this->db->prepare("DELETE FROM comments WHERE judge_id = ?");
        $stmt->bind_param("i", $judgeId);
        $stmt->execute();
        
        // Delete judge
        $stmt = $this->db->prepare("DELETE FROM judges WHERE id = ?");
        $stmt->bind_param("i", $judgeId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $this->message = "Judge deleted successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error deleting judge.";
        $this->messageType = 'error';
        return false;
    }
    
    public function getJudge($judgeId) {
        $stmt = $this->db->prepare("SELECT * FROM judges WHERE id = ?");
        $stmt->bind_param("i", $judgeId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0 ? $result->fetch_assoc() : null;
    }
    
    public function getAllJudges() {
        return $this->db->query("SELECT * FROM judges ORDER BY created_at DESC");
    }
    
    public function getJudgeStats($judgeId) {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(s.id) as scores_count,
                COUNT(DISTINCT s.contestant_id) as contestants_scored,
                COUNT(c.id) as comments_count
            FROM judges j
            LEFT JOIN scores s ON j.id = s.judge_id
            LEFT JOIN comments c ON j.id = c.judge_id
            WHERE j.id = ?
            GROUP BY j.id
        ");
        $stmt->bind_param("i", $judgeId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0 ? $result->fetch_assoc() : ['scores_count' => 0, 'contestants_scored' => 0, 'comments_count' => 0];
    }
    
    public function getMessage() {
        return $this->message;
    }
    
    public function getMessageType() {
        return $this->messageType;
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');

$judgeManager = new JudgeManager($db);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_judge') {
            $judgeManager->addJudge(
                $_POST['username'],
                $_POST['password'],
                $_POST['full_name'],
                $_POST['email']
            );
        } elseif ($_POST['action'] === 'update_judge') {
            $judgeManager->updateJudge(
                $_POST['judge_id'],
                $_POST['username'],
                $_POST['full_name'],
                $_POST['email'],
                $_POST['new_password']
            );
        } elseif ($_POST['action'] === 'delete_judge') {
            $judgeManager->deleteJudge($_POST['judge_id'], $judgeId);
        }
    }
}

// Get judge for editing
$editJudge = null;
if (isset($_GET['edit'])) {
    $editJudge = $judgeManager->getJudge($_GET['edit']);
}

$judges = $judgeManager->getAllJudges();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Judges - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
    <link rel="stylesheet" href="../Style/judges.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>⚖️ Manage Judges</h1>
            <p>Add, edit, or delete judges</p>
        </div>
        
        <?php if ($judgeManager->getMessage()): ?>
            <div class="message <?php echo $judgeManager->getMessageType(); ?>">
                <?php echo nl2br(htmlspecialchars($judgeManager->getMessage())); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2><?php echo $editJudge ? 'Edit Judge' : 'Add New Judge'; ?></h2>
            <form method="POST" action="" class="judge-form">
                <input type="hidden" name="action" value="<?php echo $editJudge ? 'update_judge' : 'add_judge'; ?>">
                <?php if ($editJudge): ?>
                    <input type="hidden" name="judge_id" value="<?php echo $editJudge['id']; ?>">
                <?php endif; ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Username *</label>
                        <input type="text" id="username" name="username" 
                               value="<?php echo $editJudge ? htmlspecialchars($editJudge['username']) : ''; ?>" 
                               placeholder="e.g., judge1" required>
                        <small class="form-hint">Must be unique, no spaces</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo $editJudge ? htmlspecialchars($editJudge['email']) : ''; ?>" 
                               placeholder="judge@example.com" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" 
                           value="<?php echo $editJudge ? htmlspecialchars($editJudge['full_name']) : ''; ?>" 
                           placeholder="e.g., John Doe" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password"><?php echo $editJudge ? 'New Password (leave blank to keep current)' : 'Password *'; ?></label>
                        <input type="password" id="password" name="<?php echo $editJudge ? 'new_password' : 'password'; ?>" 
                               placeholder="At least 6 characters" <?php echo $editJudge ? '' : 'required'; ?>>
                        <small class="form-hint">Minimum 6 characters</small>
                    </div>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn-primary">
                        <?php echo $editJudge ? '💾 Update Judge' : '➕ Add Judge'; ?>
                    </button>
                    <?php if ($editJudge): ?>
                        <a href="judges.php" class="btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>All Judges</h2>
            <?php if ($judges->num_rows > 0): ?>
                <div class="judges-list">
                    <?php while ($judge = $judges->fetch_assoc()): ?>
                        <?php $stats = $judgeManager->getJudgeStats($judge['id']); ?>
                        <div class="judge-item">
                            <div class="judge-icon">⚖️</div>
                            <div class="judge-info">
                                <h3><?php echo htmlspecialchars($judge['full_name']); ?></h3>
                                <p class="judge-username">@<?php echo htmlspecialchars($judge['username']); ?></p>
                                <p class="judge-email"><?php echo htmlspecialchars($judge['email']); ?></p>
                                <p class="judge-date">Joined: <?php echo date('M d, Y', strtotime($judge['created_at'])); ?></p>
                            </div>
                            <div class="judge-stats">
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo $stats['scores_count']; ?></span>
                                    <span class="stat-text">Scores</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo $stats['contestants_scored']; ?></span>
                                    <span class="stat-text">Contestants</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-number"><?php echo $stats['comments_count']; ?></span>
                                    <span class="stat-text">Comments</span>
                                </div>
                            </div>
                            <div class="judge-actions">
                                <a href="?edit=<?php echo $judge['id']; ?>" class="btn-edit">✏️ Edit</a>
                                <?php if ($judge['id'] != $judgeId): ?>
                                    <form method="POST" action="" style="display: inline;" 
                                          onsubmit="return confirm('Delete this judge? This cannot be undone if there are no scores.');">
                                        <input type="hidden" name="action" value="delete_judge">
                                        <input type="hidden" name="judge_id" value="<?php echo $judge['id']; ?>">
                                        <button type="submit" class="btn-delete">🗑️ Delete</button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn-delete" disabled title="Cannot delete yourself">🔒 You</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="empty-state">No judges yet. Add your first judge above!</p>
            <?php endif; ?>
        </div>
        
        <div class="card info-card">
            <h3>💡 Tips for Managing Judges</h3>
            <ul>
                <li><strong>Username:</strong> Must be unique and contain no spaces (used for login)</li>
                <li><strong>Password:</strong> At least 6 characters. Share the password securely with the judge</li>
                <li><strong>Cannot Delete Yourself:</strong> You cannot delete your own account for safety</li>
                <li><strong>Cannot Delete:</strong> Judges with scores cannot be deleted (protects your data)</li>
                <li><strong>Password Reset:</strong> To change a judge's password, edit them and enter a new password</li>
            </ul>
        </div>
    </div>
</body>
</html>