<?php
$current_page = basename($_SERVER['PHP_SELF']);
$judge = getCurrentJudge();
?>
<nav class="navbar">
    <div class="nav-container">
        <a href="/PES/Judges/dashboard.php" class="nav-brand">
            Pageant Evaluation
        </a>
        
        <ul class="nav-menu">
            <li>
                <a href="/PES/Judges/dashboard.php" class="<?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
                    <span class="nav-icon">📊</span>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="/PES/Judges/scoring.php" class="<?php echo $current_page === 'scoring.php' ? 'active' : ''; ?>">
                    <span class="nav-icon">✏️</span>
                    <span>Scoring</span>
                </a>
            </li>
            <li>
                <a href="/PES/Judges/leaderboard.php" class="<?php echo $current_page === 'leaderboard.php' ? 'active' : ''; ?>">
                    <span class="nav-icon">🏅</span>
                    <span>Leaderboard</span>
                </a>
            </li>
            <li>
                <a href="/PES/Judges/history.php" class="<?php echo $current_page === 'history.php' ? 'active' : ''; ?>">
                    <span class="nav-icon">📜</span>
                    <span>History</span>
                </a>
            </li>
            <li>
                <a href="/PES/Judges/comments.php" class="<?php echo $current_page === 'comments.php' ? 'active' : ''; ?>">
                    <span class="nav-icon">💬</span>
                    <span>Comments</span>
                </a>
            </li>
            
            <?php if ($judge && $judge['is_admin']): ?>
                <li class="nav-divider"></li>
                <li>
                    <a href="/PES/Judges/contestants.php" class="<?php echo $current_page === 'contestants.php' ? 'active' : ''; ?>">
                        <span class="nav-icon">👥</span>
                        <span>Contestants</span>
                    </a>
                </li>
                <li>
                    <a href="/PES/categories.php" class="<?php echo $current_page === 'categories.php' ? 'active' : ''; ?>">
                        <span class="nav-icon">📋</span>
                        <span>Categories</span>
                    </a>
                </li>
                <li>
                    <a href="/PES/Admin/admin_manage_judges.php" class="<?php echo $current_page === 'admin_manage_judges.php' ? 'active' : ''; ?>">
                        <span class="nav-icon">⚙️</span>
                        <span>Manage</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
        
        <div class="nav-user">
            <span class="user-name">👤 <?php echo htmlspecialchars($judge['full_name'] ?? 'Judge'); ?></span>
            <a href="/PES/logout.php" class="btn-logout">Logout</a>
        </div>
    </div>
</nav>