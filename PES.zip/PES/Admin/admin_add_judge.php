<?php
require_once __DIR__ . '/../Includes/config.php';
requireLogin();
requireAdmin(); // Only admins can access

$judge = getCurrentJudge();
$conn  = getDBConnection();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = trim($_POST['full_name']);
    
    if (!empty($username) && !empty($password) && !empty($full_name)) {
        if ($password !== $confirm_password) {
            $error = 'Passwords do not match!';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters long!';
        } else {
            // Check if username already exists
            $stmt = $conn->prepare("SELECT judge_id FROM judges WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $error = 'Username already exists!';
            } else {
                // Hash the password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $conn->prepare("INSERT INTO judges (username, password, full_name) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $username, $hashed_password, $full_name);
                
                if ($stmt->execute()) {
                    $message = "Judge added successfully! Username: $username";
                    $_POST = array(); // Clear form
                } else {
                    $error = 'Error adding judge: ' . $conn->error;
                }
            }
            
            $stmt->close();
        }
    } else {
        $error = 'Please fill all required fields';
    }
}

// Get existing judges
$judges = $conn->query("SELECT id, username, full_name, is_admin, created_at FROM judges ORDER BY id")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Judge - Admin</title>
    <link rel="stylesheet" href="../Style/style.css">
</head>
<body>
    <?php include __DIR__ . '/../Includes/navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>👨‍⚖️ Add New Judge</h1>
            <p>Register a new judge to the evaluation panel</p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <div class="scoring-section">
            <h2>Judge Information</h2>
            <form method="POST" class="comment-form">
                <div class="form-group">
                    <label for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" required
                           value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="username">Username *</label>
                    <input type="text" id="username" name="username" required
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                           placeholder="e.g., judge4">
                    <small style="color: #666;">This will be used for login</small>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Password *</label>
                        <input type="password" id="password" name="password" required minlength="6">
                        <small style="color: #666;">Minimum 6 characters</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password *</label>
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Judge</button>
                <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
        
        <div class="scoring-section">
            <h2>Existing Judges</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Role</th>
                            <th>Added On</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($judges)): ?>
                            <tr>
                                <td colspan="5" class="text-center">No judges yet</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($judges as $j): ?>
                                <tr>
                                    <td><?php echo $j['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($j['username']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($j['full_name']); ?></td>
                                    <td>
                                        <?php if ($j['is_admin']): ?>
                                            <span class="badge badge-success">Admin</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Judge</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($j['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>