<?php
class SessionManager
{
    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function requireLogin(): void
    {
        if (!isset($_SESSION['judge_id'])) {
            header('Location: login.php');
            exit;
        }
    }

    public function getSession(string $key)
    {
        return $_SESSION[$key] ?? null;
    }

    public function destroySession(): void
    {
        session_unset();
        session_destroy();
    }
}