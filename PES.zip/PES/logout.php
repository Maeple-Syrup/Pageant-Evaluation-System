<?php
require_once __DIR__ . '/Includes/config.php';
$sessionManager->destroySession();
header('Location: /PES/login.php');
exit;