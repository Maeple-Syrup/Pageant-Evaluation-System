<?php
require_once __DIR__ . '/Includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (!empty($username) && !empty($password)) {
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT id, username, password, full_name, is_admin FROM judges WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $judge = $result->fetch_assoc();
            
            if (password_verify($password, $judge['password'])) {
                $_SESSION['judge_id'] = $judge['id'];
                $_SESSION['username'] = $judge['username'];
                $_SESSION['full_name'] = $judge['full_name'];
                $_SESSION['is_admin'] = $judge['is_admin'];

                    // ---- Gmail alert ----
    require_once 'Includes/mailer.php';
    $role = $judge['is_admin'] ? 'Admin' : 'Judge';
    sendLoginAlert($role, $judge['username'], $_SERVER['REMOTE_ADDR']);
                
               header('Location: /PES/Judges/dashboard.php');
                exit();
            } else {
                $error = 'Invalid username or password';
            }
        } else {
            $error = 'Invalid username or password';
        }
        
        $stmt->close();
        $conn->close();
    } else {
        $error = 'Please enter both username and password';
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="login-page">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Judge Login - Pageant Evaluation System</title>
    <link rel="stylesheet" href="Style/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1>Pageant Evaluation System</h1>
                <p>Judge Login Panel</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
            
            <div class="login-footer">
                <p>Secure evaluation panel for authorized judges only</p>
            </div>
        </div>
    </div>
</body>
</html>