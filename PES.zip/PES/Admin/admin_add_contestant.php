<?php
require_once __DIR__ . '/../Includes/config.php';
requireLogin();
requireAdmin(); // Only admins can access

$judge = getCurrentJudge();
$conn  = getDBConnection();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contestant_number = intval($_POST['contestant_number']);
    $full_name = trim($_POST['full_name']);
    $age = intval($_POST['age']);
    
    if (!empty($full_name) && $contestant_number > 0) {
        // Check if contestant number already exists
        $stmt = $conn->prepare("SELECT contestant_id FROM contestants WHERE contestant_number = ?");
        $stmt->bind_param("i", $contestant_number);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = 'Contestant number already exists!';
        } else {
            $stmt = $conn->prepare("INSERT INTO contestants (contestant_number, full_name, age) VALUES (?, ?, ?)");
            $stmt->bind_param("isi", $contestant_number, $full_name, $age);
            
            if ($stmt->execute()) {
                $message = 'Contestant added successfully!';
                $_POST = array(); // Clear form
            } else {
                $error = 'Error adding contestant: ' . $conn->error;
            }
        }
        
        $stmt->close();
    } else {
        $error = 'Please fill all required fields';
    }
}

// Get existing contestants
$contestants = $conn->query("SELECT * FROM contestants ORDER BY contestant_number")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Contestant - Admin</title>
    <link rel="stylesheet" href="../Style/style.css">
</head>
<body>
    <?php include __DIR__ . '/../Includes/navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>➕ Add New Contestant</h1>
            <p>Register a new contestant to the pageant</p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <div class="scoring-section">
            <h2>Contestant Information</h2>
            <form method="POST" class="comment-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="contestant_number">Contestant Number *</label>
                        <input type="number" id="contestant_number" name="contestant_number" 
                               min="1" required value="<?php echo isset($_POST['contestant_number']) ? $_POST['contestant_number'] : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="age">Age</label>
                        <input type="number" id="age" name="age" min="1" max="99"
                               value="<?php echo isset($_POST['age']) ? $_POST['age'] : ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="full_name">Full Name *</label>
                    <input type="text" id="full_name" name="full_name" required
                           value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Add Contestant</button>
                <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
        
        <div class="scoring-section">
            <h2>Existing Contestants</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Number</th>
                            <th>Full Name</th>
                            <th>Age</th>
                            <th>Added On</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($contestants)): ?>
                            <tr>
                                <td colspan="4" class="text-center">No contestants yet</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($contestants as $contestant): ?>
                                <tr>
                                    <td><strong>#<?php echo $contestant['contestant_number']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($contestant['full_name']); ?></td>
                                    <td><?php echo $contestant['age'] ? $contestant['age'] : 'N/A'; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($contestant['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>