<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();

class LeaderboardCalculator {
    private $db;
    private $rankings = [];
    
    public function __construct($database) {
        $this->db = $database;
        $this->calculateRankings();
    }
    
    private function calculateRankings() {
        $query = "
            SELECT 
                c.id,
                c.contestant_number,
                c.full_name,
                c.age,
                AVG(s.score * cat.weight) as weighted_avg,
                COUNT(DISTINCT s.judge_id) as judges_count,
                COUNT(s.id) as total_scores
            FROM contestants c
            LEFT JOIN scores s ON c.id = s.contestant_id
            LEFT JOIN categories cat ON s.category_id = cat.id
            GROUP BY c.id
            ORDER BY weighted_avg DESC, c.contestant_number ASC
        ";
        
        $result = $this->db->query($query);
        $rank = 1;
        
        while ($row = $result->fetch_assoc()) {
            $row['rank'] = $rank++;
            $this->rankings[] = $row;
        }
    }
    
    public function getRankings() {
        return $this->rankings;
    }
    
    public function getCategoryBreakdown($contestantId) {
        $stmt = $this->db->prepare("
            SELECT 
                cat.category_name,
                cat.max_score,
                AVG(s.score) as avg_score,
                COUNT(s.id) as score_count
            FROM categories cat
            LEFT JOIN scores s ON cat.id = s.category_id AND s.contestant_id = ?
            GROUP BY cat.id
            ORDER BY cat.display_order
        ");
        $stmt->bind_param("i", $contestantId);
        $stmt->execute();
        return $stmt->get_result();
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');

$leaderboard = new LeaderboardCalculator($db);
$rankings = $leaderboard->getRankings();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
    <link rel="stylesheet" href="../Style/leaderboard.css">
    <link rel="stylesheet" href="../Style/print.css" media="print">
</head>
<body>
    
    
    <div class="container">
        <class="page-header">
            <h1>🏆 Leaderboard</h1>
            <p>Overall rankings and results</p>
                <a href="/PES/Judges/print_leaderboard.php" target="_blank" class="btn-secondary">🖨 Print Results</a>
        </div>
        
        <div class="leaderboard-container">
            <?php if (!empty($rankings)): ?>
                <?php foreach ($rankings as $contestant): ?>
                    <div class="leaderboard-card rank-<?php echo $contestant['rank']; ?>">
                        <div class="rank-badge">
                            <?php if ($contestant['rank'] === 1): ?>
                                🥇
                            <?php elseif ($contestant['rank'] === 2): ?>
                                🥈
                            <?php elseif ($contestant['rank'] === 3): ?>
                                🥉
                            <?php else: ?>
                                #<?php echo $contestant['rank']; ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="contestant-info">
                            <h3>Contestant #<?php echo $contestant['contestant_number']; ?></h3>
                            <h2><?php echo htmlspecialchars($contestant['full_name']); ?></h2>
                            <p>Age: <?php echo $contestant['age']; ?></p>
                        </div>
                        
                        <div class="score-summary">
                            <div class="overall-score">
                                <span class="score-label">Overall Score</span>
                                <span class="score-value">
                                    <?php echo $contestant['weighted_avg'] ? number_format($contestant['weighted_avg'], 2) : 'N/A'; ?>
                                </span>
                            </div>
                            <div class="score-details">
                                <span><?php echo $contestant['judges_count']; ?> Judges</span>
                                <span>•</span>
                                <span><?php echo $contestant['total_scores']; ?> Scores</span>
                            </div>
                        </div>
                        
                        <button class="btn-details" onclick="toggleDetails(<?php echo $contestant['id']; ?>)">
                            View Details
                        </button>
                        
                        <div id="details-<?php echo $contestant['id']; ?>" class="category-details" style="display: none;">
                            <h4>Category Breakdown</h4>
                            <table class="details-table">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Avg Score</th>
                                        <th>Scores</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $breakdown = $leaderboard->getCategoryBreakdown($contestant['id']);
                                    while ($cat = $breakdown->fetch_assoc()): 
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($cat['category_name']); ?></td>
                                            <td>
                                                <?php if ($cat['avg_score']): ?>
                                                    <span class="score-badge">
                                                        <?php echo number_format($cat['avg_score'], 2); ?>/<?php echo $cat['max_score']; ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="no-score">No scores</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $cat['score_count']; ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="empty-state">No contestants found.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function toggleDetails(contestantId) {
            const details = document.getElementById('details-' + contestantId);
            if (details.style.display === 'none') {
                details.style.display = 'block';
            } else {
                details.style.display = 'none';
            }
        }
    </script>
</body>
</html>