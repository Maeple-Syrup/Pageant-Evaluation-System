<?php
require_once __DIR__ . '/../Includes/config.php';
requireLogin();

$db  = getDBConnection();
$judgeId = $sessionManager->getSession('judge_id');

// same SQL you already use
$rankings = $db->query("
  SELECT c.contestant_number, c.full_name, c.age,
         AVG(s.score * cat.weight) AS weighted_avg,
         COUNT(DISTINCT s.judge_id) AS judges_count
  FROM contestants c
  LEFT JOIN scores s  ON c.id = s.contestant_id
  LEFT JOIN categories cat ON s.category_id = cat.id
  GROUP BY c.id
  ORDER BY weighted_avg DESC, c.contestant_number ASC
")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Leaderboard Results</title>
  <style>
     body{font-family:Arial,Helvetica,sans-serif;margin:0;padding:.5cm;background:#fff}
     h1{text-align:center;margin-bottom:.5cm;font-size:20px}
     table{width:100%;border-collapse:collapse;font-size:12px}
     th,td{border:1px solid #000;padding:6px;text-align:center}
     th{background:#ddd;-webkit-print-color-adjust:exact}
     .rank{width:40px}
     .no{width:50px}
     .score{font-weight:bold}
     @page{margin:1cm;size:A4 portrait}
  </style>
</head>
<body>
  <h1>Pageant Final Results</h1>
  <table>
    <thead>
      <tr>
        <th class="rank">Rank</th>
        <th class="no">#</th>
        <th>Full Name</th>
        <th>Age</th>
        <th>Weighted Avg</th>
        <th>Judges</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $rank = 1;
    foreach ($rankings as $r): ?>
      <tr>
        <td><?= $rank++ ?></td>
        <td><?= $r['contestant_number'] ?></td>
        <td><?= htmlspecialchars($r['full_name']) ?></td>
        <td><?= $r['age'] ?></td>
        <td class="score"><?= number_format($r['weighted_avg'],2) ?></td>
        <td><?= $r['judges_count'] ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <p style="margin-top:1cm;font-size:11px">
    Printed: <?= date('F j, Y, g:i a') ?><br>
    Pageant Chairman: ____________________
  </p>

  <script>window.print();</script>
</body>
</html>