<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();

class DashboardStats {
    private $db;
    private $judgeId;
    private $stats = [];
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
        $this->calculateStats();
    }
    
    private function calculateStats() {
        // Total contestants
        $result = $this->db->query("SELECT COUNT(*) as total FROM contestants");
        $this->stats['total_contestants'] = $result->fetch_assoc()['total'];
        
        // Total categories
        $result = $this->db->query("SELECT COUNT(*) as total FROM categories");
        $this->stats['total_categories'] = $result->fetch_assoc()['total'];
        
        // Scores submitted by this judge
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM scores WHERE judge_id = ?");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        $this->stats['my_scores'] = $stmt->get_result()->fetch_assoc()['total'];
        
        // Expected total scores
        $this->stats['expected_scores'] = $this->stats['total_contestants'] * $this->stats['total_categories'];
        
        // Progress percentage
        $this->stats['progress'] = $this->stats['expected_scores'] > 0 
            ? round(($this->stats['my_scores'] / $this->stats['expected_scores']) * 100, 1)
            : 0;
        
        // Comments count
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM comments WHERE judge_id = ?");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        $this->stats['my_comments'] = $stmt->get_result()->fetch_assoc()['total'];
    }
    
    public function getStats() {
        return $this->stats;
    }
}

class RecentActivity {
    private $db;
    private $judgeId;
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
    }
    
    public function getRecentScores($limit = 5) {
        $stmt = $this->db->prepare("
            SELECT s.score, s.scored_at, 
                   c.full_name as contestant_name, 
                   cat.category_name
            FROM scores s
            JOIN contestants c ON s.contestant_id = c.id
            JOIN categories cat ON s.category_id = cat.id
            WHERE s.judge_id = ?
            ORDER BY s.scored_at DESC
            LIMIT ?
        ");
        $stmt->bind_param("ii", $this->judgeId, $limit);
        $stmt->execute();
        return $stmt->get_result();
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');

$dashboardStats = new DashboardStats($db, $judgeId);
$stats = $dashboardStats->getStats();

$recentActivity = new RecentActivity($db, $judgeId);
$recentScores = $recentActivity->getRecentScores(5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
</head>
<body>
    <?php include __DIR__ . '/../Includes/navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📊 Dashboard</h1>
            <p>Welcome back, <strong><?php echo htmlspecialchars($judgeName); ?></strong>! Admin Judge</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-content">
                    <span class="stat-value"><?php echo $stats['total_contestants']; ?></span>
                    <span class="stat-label">Contestants</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📋</div>
                <div class="stat-content">
                    <span class="stat-value"><?php echo $stats['total_categories']; ?></span>
                    <span class="stat-label">Categories</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                    <span class="stat-value"><?php echo $stats['my_scores']; ?>/<?php echo $stats['expected_scores']; ?></span>
                    <span class="stat-label">Scores Submitted</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💬</div>
                <div class="stat-content">
                    <span class="stat-value"><?php echo $stats['my_comments']; ?></span>
                    <span class="stat-label">Comments</span>
                </div>
            </div>
        </div>
        
        <div class="progress-section">
            <h2>🎯 Scoring Progress</h2>
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo $stats['progress']; ?>%">
                    <?php echo $stats['progress']; ?>% Complete
                </div>
            </div>
            <p style="margin-top: 12px; color: var(--text-secondary); font-size: 0.9rem;">
                <?php 
                $remaining = $stats['expected_scores'] - $stats['my_scores'];
                if ($remaining > 0) {
                    echo "You have <strong>{$remaining} score" . ($remaining != 1 ? 's' : '') . "</strong> remaining to complete your evaluation.";
                } else {
                    echo "🎉 Congratulations! You've completed all evaluations.";
                }
                ?>
            </p>
        </div>
        
        <div class="card">
            <h2>📜 Recent Scores</h2>
            <?php if ($recentScores->num_rows > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Contestant</th>
                            <th>Category</th>
                            <th>Score</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $recentScores->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['contestant_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                                <td><span class="score-badge"><?php echo $row['score']; ?></span></td>
                                <td><?php echo date('M d, Y H:i', strtotime($row['scored_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="empty-state">
                    No scores submitted yet. 
                    <a href="scoring.php">Start scoring contestants now! →</a>
                </p>
            <?php endif; ?>
        </div>
        
        <div class="card info-card">
            <h3>💡 Quick Actions</h3>
            <ul>
                <li><strong>Score Contestants:</strong> Go to the <a href="scoring.php">Scoring</a> page to evaluate contestants</li>
                <li><strong>View Rankings:</strong> Check the <a href="leaderboard.php">Leaderboard</a> to see current standings</li>
                <li><strong>Add Comments:</strong> Leave feedback on the <a href="comments.php">Comments</a> page</li>
                <li><strong>Review History:</strong> View all your past scores in <a href="history.php">History</a></li>
            </ul>
        </div>
    </div>
</body>
</html>