<?php
/**
 * Index Page - Entry Point
 * Redirects to appropriate page based on login status
 */

// Start session first
session_start();

// Check if user is logged in
if (isset($_SESSION['judge_id']) && isset($_SESSION['username'])) {
    // Redirect to dashboard if logged in
    header("Location: dashboard.php");
} else {
    // Redirect to login if not logged in
    header("Location: login.php");
}

exit();
?>