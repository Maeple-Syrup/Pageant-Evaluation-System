<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();


class ScoringHistory {
    private $db;
    private $judgeId;
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
    }
    
    public function getAllScores($filterContestant = null, $filterCategory = null) {
        $query = "
            SELECT 
                s.id,
                s.score,
                s.scored_at,
                s.updated_at,
                c.contestant_number,
                c.full_name as contestant_name,
                cat.category_name,
                cat.max_score
            FROM scores s
            JOIN contestants c ON s.contestant_id = c.id
            JOIN categories cat ON s.category_id = cat.id
            WHERE s.judge_id = ?
        ";
        
        $params = [$this->judgeId];
        $types = "i";
        
        if ($filterContestant) {
            $query .= " AND s.contestant_id = ?";
            $params[] = $filterContestant;
            $types .= "i";
        }
        
        if ($filterCategory) {
            $query .= " AND s.category_id = ?";
            $params[] = $filterCategory;
            $types .= "i";
        }
        
        $query .= " ORDER BY s.scored_at DESC";
        
        $stmt = $this->db->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        return $stmt->get_result();
    }
    
    public function getStatistics() {
        $stats = [];
        
        // Total scores
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM scores WHERE judge_id = ?");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        $stats['total_scores'] = $stmt->get_result()->fetch_assoc()['total'];
        
        // Average score
        $stmt = $this->db->prepare("SELECT AVG(score) as avg_score FROM scores WHERE judge_id = ?");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stats['avg_score'] = $result['avg_score'] ? round($result['avg_score'], 2) : 0;
        
        // Highest score
        $stmt = $this->db->prepare("SELECT MAX(score) as max_score FROM scores WHERE judge_id = ?");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        $stats['max_score'] = $stmt->get_result()->fetch_assoc()['max_score'] ?? 0;
        
        // Lowest score
        $stmt = $this->db->prepare("SELECT MIN(score) as min_score FROM scores WHERE judge_id = ?");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        $stats['min_score'] = $stmt->get_result()->fetch_assoc()['min_score'] ?? 0;
        
        return $stats;
    }
    
    public function getScoresByCategory() {
        $stmt = $this->db->prepare("
            SELECT 
                cat.category_name,
                COUNT(s.id) as score_count,
                AVG(s.score) as avg_score
            FROM categories cat
            LEFT JOIN scores s ON cat.id = s.category_id AND s.judge_id = ?
            GROUP BY cat.id
            ORDER BY cat.display_order
        ");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        return $stmt->get_result();
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');

$history = new ScoringHistory($db, $judgeId);

// Get filter parameters
$filterContestant = $_GET['contestant'] ?? null;
$filterCategory = $_GET['category'] ?? null;

$scores = $history->getAllScores($filterContestant, $filterCategory);
$statistics = $history->getStatistics();
$categoryStats = $history->getScoresByCategory();

// Get contestants and categories for filters
$contestants = $db->query("SELECT id, contestant_number, full_name FROM contestants ORDER BY contestant_number");
$categories = $db->query("SELECT id, category_name FROM categories ORDER BY display_order");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
    <link rel="stylesheet" href="../Style/history.css">
</head>
<body>
    
    
    <div class="container">
        <div class="page-header">
            <h1>📜 Scoring History</h1>
            <p>Your complete scoring record</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-content">
                    <div class="stat-value"><?php echo $statistics['total_scores']; ?></div>
                    <div class="stat-label">Total Scores</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📈</div>
                <div class="stat-content">
                    <div class="stat-value"><?php echo $statistics['avg_score']; ?></div>
                    <div class="stat-label">Average Score</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⬆️</div>
                <div class="stat-content">
                    <div class="stat-value"><?php echo $statistics['max_score']; ?></div>
                    <div class="stat-label">Highest Score</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⬇️</div>
                <div class="stat-content">
                    <div class="stat-value"><?php echo $statistics['min_score']; ?></div>
                    <div class="stat-label">Lowest Score</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>Category Statistics</h2>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Scores Given</th>
                        <th>Average Score</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($cat = $categoryStats->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($cat['category_name']); ?></td>
                            <td><?php echo $cat['score_count']; ?></td>
                            <td>
                                <?php if ($cat['avg_score']): ?>
                                    <span class="score-badge"><?php echo number_format($cat['avg_score'], 2); ?></span>
                                <?php else: ?>
                                    <span class="no-score">N/A</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>All Scores</h2>
                <form method="GET" action="" class="filter-form">
                    <select name="contestant" onchange="this.form.submit()">
                        <option value="">All Contestants</option>
                        <?php while ($c = $contestants->fetch_assoc()): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $filterContestant == $c['id'] ? 'selected' : ''; ?>>
                                #<?php echo $c['contestant_number']; ?> - <?php echo htmlspecialchars($c['full_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    
                    <select name="category" onchange="this.form.submit()">
                        <option value="">All Categories</option>
                        <?php while ($cat = $categories->fetch_assoc()): ?>
                            <option value="<?php echo $cat['id']; ?>" <?php echo $filterCategory == $cat['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    
                    <?php if ($filterContestant || $filterCategory): ?>
                        <a href="history.php" class="btn-secondary">Clear Filters</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <?php if ($scores->num_rows > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Contestant</th>
                            <th>Category</th>
                            <th>Score</th>
                            <th>Submitted</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $scores->fetch_assoc()): ?>
                            <tr>
                                <td>#<?php echo $row['contestant_number']; ?> - <?php echo htmlspecialchars($row['contestant_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                                <td><span class="score-badge"><?php echo $row['score']; ?>/<?php echo $row['max_score']; ?></span></td>
                                <td><?php echo date('M d, Y H:i', strtotime($row['scored_at'])); ?></td>
                                <td>
                                    <?php 
                                    if ($row['scored_at'] != $row['updated_at']) {
                                        echo date('M d, Y H:i', strtotime($row['updated_at']));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="empty-state">No scores found with the current filters.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>