<?php
require_once __DIR__ . '/../Includes/config.php';
require_once __DIR__ . '/../Includes/navbar.php';
$sessionManager->requireLogin();

/* ---------- CREATE DB HANDLE ---------- */
$db = getDBConnection();

class ScoringHandler {
    private $db;
    private $judgeId;
    private $message = '';
    private $messageType = '';
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
    }
    
    public function addOrUpdateScore($contestantId, $categoryId, $score) {
        // Validate score
        $stmt = $this->db->prepare("SELECT max_score FROM categories WHERE id = ?");
        $stmt->bind_param("i", $categoryId);
        $stmt->execute();
        $result = $stmt->get_result();
        $category = $result->fetch_assoc();
        
        if ($score < 0 || $score > $category['max_score']) {
            $this->message = "Score must be between 0 and " . $category['max_score'];
            $this->messageType = 'error';
            return false;
        }
        
        // Insert or update score
        $stmt = $this->db->prepare("
            INSERT INTO scores (judge_id, contestant_id, category_id, score) 
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE score = ?, updated_at = CURRENT_TIMESTAMP
        ");
        $stmt->bind_param("iiidd", $this->judgeId, $contestantId, $categoryId, $score, $score);
        
        if ($stmt->execute()) {
            $this->message = "Score saved successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error saving score.";
        $this->messageType = 'error';
        return false;
    }
    
    public function deleteScore($scoreId) {
        $stmt = $this->db->prepare("DELETE FROM scores WHERE id = ? AND judge_id = ?");
        $stmt->bind_param("ii", $scoreId, $this->judgeId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $this->message = "Score deleted successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error deleting score.";
        $this->messageType = 'error';
        return false;
    }
    
    public function getExistingScore($contestantId, $categoryId) {
        $stmt = $this->db->prepare("
            SELECT score FROM scores 
            WHERE judge_id = ? AND contestant_id = ? AND category_id = ?
        ");
        $stmt->bind_param("iii", $this->judgeId, $contestantId, $categoryId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return $result->fetch_assoc()['score'];
        }
        return null;
    }
    
    public function getMessage() {
        return $this->message;
    }
    
    public function getMessageType() {
        return $this->messageType;
    }
}

class ScoringData {
    private $db;
    private $judgeId;
    
    public function __construct($database, $judgeId) {
        $this->db = $database;
        $this->judgeId = $judgeId;
    }
    
    public function getContestants() {
        return $this->db->query("SELECT * FROM contestants ORDER BY contestant_number");
    }
    
    public function getCategories() {
        return $this->db->query("SELECT * FROM categories ORDER BY display_order");
    }
    
    public function getMyScores() {
        $stmt = $this->db->prepare("
            SELECT s.id, s.score, s.scored_at,
                   c.contestant_number, c.full_name as contestant_name,
                   cat.category_name, cat.max_score
            FROM scores s
            JOIN contestants c ON s.contestant_id = c.id
            JOIN categories cat ON s.category_id = cat.id
            WHERE s.judge_id = ?
            ORDER BY s.scored_at DESC
        ");
        $stmt->bind_param("i", $this->judgeId);
        $stmt->execute();
        return $stmt->get_result();
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('full_name');

$scoringHandler = new ScoringHandler($db, $judgeId);
$scoringData = new ScoringData($db, $judgeId);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_score') {
            $scoringHandler->addOrUpdateScore(
                $_POST['contestant_id'],
                $_POST['category_id'],
                $_POST['score']
            );
        } elseif ($_POST['action'] === 'delete_score') {
            $scoringHandler->deleteScore($_POST['score_id']);
        }
    }
}

$contestants = $scoringData->getContestants();
$categories = $scoringData->getCategories();
$myScores = $scoringData->getMyScores();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scoring - Pageant System</title>
    <link rel="stylesheet" href="../Style/style.css">
    <link rel="stylesheet" href="../Style/scoring.css">
</head>
<body>
    
    
    <div class="container">
        <div class="page-header">
            <h1>Scoring</h1>
            <p>Submit scores for contestants</p>
        </div>
        
        <?php if ($scoringHandler->getMessage()): ?>
            <div class="message <?php echo $scoringHandler->getMessageType(); ?>">
                <?php echo htmlspecialchars($scoringHandler->getMessage()); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2>Submit Score</h2>
            <form method="POST" action="" class="scoring-form">
                <input type="hidden" name="action" value="add_score">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="contestant_id">Contestant</label>
                        <select id="contestant_id" name="contestant_id" required>
                            <option value="">Select Contestant</option>
                            <?php while ($contestant = $contestants->fetch_assoc()): ?>
                                <option value="<?php echo $contestant['id']; ?>">
                                    #<?php echo $contestant['contestant_number']; ?> - <?php echo htmlspecialchars($contestant['full_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">Category</label>
                        <select id="category_id" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php while ($category = $categories->fetch_assoc()): ?>
                                <option value="<?php echo $category['id']; ?>" data-max="<?php echo $category['max_score']; ?>">
                                    <?php echo htmlspecialchars($category['category_name']); ?> (Max: <?php echo $category['max_score']; ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="score">Score</label>
                    <input type="number" id="score" name="score" step="0.01" min="0" max="100" required>
                    <small class="form-hint">Enter score based on the category's maximum value</small>
                </div>
                
                <button type="submit" class="btn-primary">Submit Score</button>
            </form>
        </div>
        
        <div class="card">
            <h2>My Submitted Scores</h2>
            <?php if ($myScores->num_rows > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Contestant</th>
                            <th>Category</th>
                            <th>Score</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $myScores->fetch_assoc()): ?>
                            <tr>
                                <td>#<?php echo $row['contestant_number']; ?> - <?php echo htmlspecialchars($row['contestant_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                                <td><span class="score-badge"><?php echo $row['score']; ?>/<?php echo $row['max_score']; ?></span></td>
                                <td><?php echo date('M d, Y H:i', strtotime($row['scored_at'])); ?></td>
                                <td>
                                    <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Delete this score?');">
                                        <input type="hidden" name="action" value="delete_score">
                                        <input type="hidden" name="score_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="btn-delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="empty-state">No scores submitted yet.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        document.getElementById('category_id').addEventListener('change', function() {
            const maxScore = this.options[this.selectedIndex].getAttribute('data-max');
            const scoreInput = document.getElementById('score');
            if (maxScore) {
                scoreInput.max = maxScore;
            }
        });
    </script>
</body>
</html>