<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';
require_once __DIR__ . '/PHPMailer/Exception.php';

function sendLoginAlert(string $who, string $user, string $ip): void
{
    $mail = new PHPMailer(true);
    try {
        //Server
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'msyrup640@gmail.com';      // YOUR GMAIL
        $mail->Password   = 'rjsi mcnn zgmg ksis'; // APP-PASSWORD
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        //Recipients
        $mail->setFrom('msyrup640@gmail.com', 'Pageant System');
        $mail->addAddress('msyrup640@gmail.com');        // send TO yourself
        $mail->isHTML(true);
        $mail->Subject = 'Pageant Login Alert';
        $mail->Body    = "
          <h3>Someone just logged in</h3>
          <p><b>Type:</b> $who</p>
          <p><b>User:</b> $user</p>
          <p><b>IP:</b> $ip</p>
          <p><b>Time:</b> ".date('Y-m-d H:i:s')."</p>
        ";

        $mail->send();
    } catch (Exception $e) {
        error_log('Mail error: '.$mail->ErrorInfo);
    }
}