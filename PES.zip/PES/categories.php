<?php
require_once __DIR__ . '/Includes/config.php';
require_once __DIR__ . '/Includes/navbar.php';
$sessionManager->requireLogin();

class CategoryManager {
    private $db;
    private $message = '';
    private $messageType = '';
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function addCategory($categoryName, $description, $maxScore, $weight, $displayOrder) {
        if (empty(trim($categoryName))) {
            $this->message = "Category name is required.";
            $this->messageType = 'error';
            return false;
        }
        
        if ($maxScore <= 0) {
            $this->message = "Max score must be greater than 0.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("
            INSERT INTO categories (category_name, description, max_score, weight, display_order) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssidi", $categoryName, $description, $maxScore, $weight, $displayOrder);
        
        if ($stmt->execute()) {
            $this->message = "Category added successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error adding category.";
        $this->messageType = 'error';
        return false;
    }
    
    public function updateCategory($categoryId, $categoryName, $description, $maxScore, $weight, $displayOrder) {
        if (empty(trim($categoryName))) {
            $this->message = "Category name is required.";
            $this->messageType = 'error';
            return false;
        }
        
        if ($maxScore <= 0) {
            $this->message = "Max score must be greater than 0.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE categories 
            SET category_name = ?, description = ?, max_score = ?, weight = ?, display_order = ?
            WHERE id = ?
        ");
        $stmt->bind_param("ssidii", $categoryName, $description, $maxScore, $weight, $displayOrder, $categoryId);
        
        if ($stmt->execute()) {
            $this->message = "Category updated successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error updating category.";
        $this->messageType = 'error';
        return false;
    }
    
    public function deleteCategory($categoryId) {
        // Check if category has scores
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM scores WHERE category_id = ?");
        $stmt->bind_param("i", $categoryId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result['count'] > 0) {
            $this->message = "Cannot delete category with existing scores. Delete scores first.";
            $this->messageType = 'error';
            return false;
        }
        
        $stmt = $this->db->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param("i", $categoryId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $this->message = "Category deleted successfully!";
            $this->messageType = 'success';
            return true;
        }
        
        $this->message = "Error deleting category.";
        $this->messageType = 'error';
        return false;
    }
    
    public function getCategory($categoryId) {
        $stmt = $this->db->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->bind_param("i", $categoryId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0 ? $result->fetch_assoc() : null;
    }
    
    public function getAllCategories() {
        return $this->db->query("SELECT * FROM categories ORDER BY display_order, id");
    }
    
    public function getMessage() {
        return $this->message;
    }
    
    public function getMessageType() {
        return $this->messageType;
    }
}

$judgeId = $sessionManager->getSession('judge_id');
$judgeName = $sessionManager->getSession('judge_name');

$categoryManager = new CategoryManager($db);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_category') {
            $categoryManager->addCategory(
                $_POST['category_name'],
                $_POST['description'],
                $_POST['max_score'],
                $_POST['weight'],
                $_POST['display_order']
            );
        } elseif ($_POST['action'] === 'update_category') {
            $categoryManager->updateCategory(
                $_POST['category_id'],
                $_POST['category_name'],
                $_POST['description'],
                $_POST['max_score'],
                $_POST['weight'],
                $_POST['display_order']
            );
        } elseif ($_POST['action'] === 'delete_category') {
            $categoryManager->deleteCategory($_POST['category_id']);
        }
    }
}

// Get category for editing
$editCategory = null;
if (isset($_GET['edit'])) {
    $editCategory = $categoryManager->getCategory($_GET['edit']);
}

$categories = $categoryManager->getAllCategories();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Pageant System</title>
    <link rel="stylesheet" href="/PES/Style/style.css">
    <link rel="stylesheet" href="/PES/Style/categories.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📋 Manage Categories</h1>
            <p>Add, edit, or delete judging categories</p>
        </div>
        
        <?php if ($categoryManager->getMessage()): ?>
            <div class="message <?php echo $categoryManager->getMessageType(); ?>">
                <?php echo htmlspecialchars($categoryManager->getMessage()); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2><?php echo $editCategory ? 'Edit Category' : 'Add New Category'; ?></h2>
            <form method="POST" action="" class="category-form">
                <input type="hidden" name="action" value="<?php echo $editCategory ? 'update_category' : 'add_category'; ?>">
                <?php if ($editCategory): ?>
                    <input type="hidden" name="category_id" value="<?php echo $editCategory['id']; ?>">
                <?php endif; ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="category_name">Category Name *</label>
                        <input type="text" id="category_name" name="category_name" 
                               value="<?php echo $editCategory ? htmlspecialchars($editCategory['category_name']) : ''; ?>" 
                               placeholder="e.g., Beauty, Talent, Intelligence" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="display_order">Display Order</label>
                        <input type="number" id="display_order" name="display_order" 
                               value="<?php echo $editCategory ? $editCategory['display_order'] : '0'; ?>" 
                               min="0" step="1">
                        <small class="form-hint">Lower numbers appear first</small>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3" 
                              placeholder="Brief description of what this category judges..."><?php echo $editCategory ? htmlspecialchars($editCategory['description']) : ''; ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="max_score">Maximum Score *</label>
                        <input type="number" id="max_score" name="max_score" 
                               value="<?php echo $editCategory ? $editCategory['max_score'] : '100'; ?>" 
                               min="1" step="1" required>
                        <small class="form-hint">Maximum points judges can award</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="weight">Weight/Multiplier</label>
                        <input type="number" id="weight" name="weight" 
                               value="<?php echo $editCategory ? $editCategory['weight'] : '1.00'; ?>" 
                               min="0.01" step="0.01">
                        <small class="form-hint">1.00 = normal, 2.00 = double importance</small>
                    </div>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn-primary">
                        <?php echo $editCategory ? '💾 Update Category' : '➕ Add Category'; ?>
                    </button>
                    <?php if ($editCategory): ?>
                        <a href="categories.php" class="btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>All Categories</h2>
            <?php if ($categories->num_rows > 0): ?>
                <div class="categories-grid">
                    <?php while ($cat = $categories->fetch_assoc()): ?>
                        <div class="category-item">
                            <div class="category-header">
                                <h3><?php echo htmlspecialchars($cat['category_name']); ?></h3>
                                <span class="order-badge">Order: <?php echo $cat['display_order']; ?></span>
                            </div>
                            
                            <?php if ($cat['description']): ?>
                                <p class="category-description"><?php echo htmlspecialchars($cat['description']); ?></p>
                            <?php endif; ?>
                            
                            <div class="category-details-grid">
                                <div class="detail-item">
                                    <span class="detail-label">Max Score:</span>
                                    <span class="detail-value"><?php echo $cat['max_score']; ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Weight:</span>
                                    <span class="detail-value"><?php echo $cat['weight']; ?>x</span>
                                </div>
                            </div>
                            
                            <div class="category-actions">
                                <a href="?edit=<?php echo $cat['id']; ?>" class="btn-edit">✏️ Edit</a>
                                <form method="POST" action="" style="display: inline;" 
                                      onsubmit="return confirm('Delete this category? This cannot be undone if there are no scores.');">
                                    <input type="hidden" name="action" value="delete_category">
                                    <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                    <button type="submit" class="btn-delete">🗑️ Delete</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="empty-state">No categories yet. Add your first category above!</p>
            <?php endif; ?>
        </div>
        
        <div class="card info-card">
            <h3>💡 Tips for Managing Categories</h3>
            <ul>
                <li><strong>Display Order:</strong> Controls the order categories appear (0 = first, 1 = second, etc.)</li>
                <li><strong>Max Score:</strong> Set the maximum points judges can give (commonly 100, 50, or 10)</li>
                <li><strong>Weight:</strong> Use weights to make certain categories more important (e.g., 2.0 = twice as important)</li>
                <li><strong>Cannot Delete:</strong> Categories with existing scores cannot be deleted (protects your data)</li>
                <li><strong>Common Categories:</strong> Beauty, Talent, Intelligence/Q&A, Evening Gown, Swimsuit, Personality</li>
            </ul>
        </div>
    </div>
</body>
</html>