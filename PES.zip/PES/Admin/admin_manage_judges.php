<?php
require_once __DIR__ . '/../Includes/config.php';
requireLogin();
requireAdmin(); // Only admins can access

$judge = getCurrentJudge();
$conn  = getDBConnection();

$message = '';
$error = '';

// Handle delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'delete_judge') {
        $delete_id = intval($_POST['judge_id']);
        
        // Check if trying to delete an admin
        $stmt = $conn->prepare("SELECT is_admin FROM judges WHERE judge_id = ?");
        $stmt->bind_param("i", $delete_id);
        $stmt->execute();
        $target = $stmt->get_result()->fetch_assoc();
        
        if ($target['is_admin'] == 1) {
            $error = '❌ Cannot delete admin accounts!';
        } elseif ($delete_id == $judge['judge_id']) {
            $error = '❌ Cannot delete yourself!';
        } else {
            // Check if judge has scored anything
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM scores WHERE judge_id = ?");
            $stmt->bind_param("i", $delete_id);
            $stmt->execute();
            $score_count = $stmt->get_result()->fetch_assoc()['count'];
            
            if ($score_count > 0) {
                $error = '❌ Cannot delete judge with existing scores! Remove scores first.';
            } else {
                // Safe to delete
                $stmt = $conn->prepare("DELETE FROM judges WHERE judge_id = ?");
                $stmt->bind_param("i", $delete_id);
                
                if ($stmt->execute()) {
                    $message = '✅ Judge deleted successfully!';
                } else {
                    $error = '❌ Error deleting judge';
                }
            }
        }
        $stmt->close();
    }
}

// Get all judges
$judges = $conn->query("SELECT id, username, full_name, is_admin, created_at FROM judges ORDER BY is_admin DESC, id")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Judges - Admin Panel</title>
    <link rel="stylesheet" href="../Style/style.css">
</head>
<body>
    <?php include __DIR__ . '/../Includes/navbar.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>👥 Manage Judges</h1>
            <p>Admin Panel - View and manage all judges</p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="scoring-section">
            <h2>All Judges</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Role</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($judges as $j): ?>
                            <tr>
                                <td><?php echo $j['id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($j['username']); ?></strong></td>
                                <td><?php echo htmlspecialchars($j['full_name']); ?></td>
                                <td>
                                    <?php if ($j['is_admin']): ?>
                                        <span class="badge badge-success">Admin</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Judge</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($j['created_at'])); ?></td>
                                <td>
                                    <?php if ($j['is_admin']): ?>
                                        <span style="color: #999; font-size: 12px;">Protected</span>
                                    <?php elseif ($j['id'] == $judge['judge_id']): ?>
                                        <span style="color: #999; font-size: 12px;">You</span>
                                    <?php else: ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this judge?');">
                                            <input type="hidden" name="action" value="delete_judge">
                                            <input type="hidden" name="judge_id" value="<?php echo $j['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="alert alert-info">
            <strong>ℹ️ Protection Rules:</strong>
            <ul style="margin: 10px 0 0 20px;">
                <li>Admin accounts cannot be deleted</li>
                <li>Judges with existing scores cannot be deleted</li>
                <li>You cannot delete yourself</li>
            </ul>
        </div>
    </div>
</body>
</html>