<?php
require_once __DIR__ . '/../Includes/config.php';
requireLogin();
requireAdmin();                 // only admins

$db = getDBConnection();

/* ---------- delete actions ---------- */
if (isset($_POST['delete_score'])) {
    $id = (int)$_POST['score_id'];
    $db->query("DELETE FROM scores WHERE id = $id");
    header("Location: ScoresComments.php?deleted=score");
    exit;
}
if (isset($_POST['delete_comment'])) {
    $id = (int)$_POST['comment_id'];
    $db->query("DELETE FROM comments WHERE id = $id");
    header("Location: ScoresComments.php?deleted=comment");
    exit;
}

/* ---------- filters ---------- */
$judgeF   = isset($_GET['judge'])   ? (int)$_GET['judge']   : 0;
$contF    = isset($_GET['contestant']) ? (int)$_GET['contestant'] : 0;
$catF     = isset($_GET['category'])  ? (int)$_GET['category']   : 0;

$judges  = $db->query("SELECT id, full_name FROM judges ORDER BY full_name");
$conts   = $db->query("SELECT id, contestant_number, full_name FROM contestants ORDER BY contestant_number");
$cats    = $db->query("SELECT id, category_name FROM categories ORDER BY display_order");

/* ---------- build where ---------- */
$where = ['1=1'];
if ($judgeF)   $where[] = "s.judge_id   = $judgeF";
if ($contF)    $where[] = "s.contestant_id = $contF";
if ($catF)     $where[] = "s.category_id   = $catF";
$whereSql = implode(' AND ', $where);

/* ---------- scores ---------- */
$scores = $db->query("
  SELECT s.id, s.score, s.scored_at,
         j.full_name AS judge_name,
         c.contestant_number, c.full_name AS contestant_name,
         cat.category_name, cat.max_score
  FROM scores s
  JOIN judges   j  ON j.id = s.judge_id
  JOIN contestants c ON c.id = s.contestant_id
  JOIN categories cat ON cat.id = s.category_id
  WHERE $whereSql
  ORDER BY s.scored_at DESC
");

/* ---------- comments ---------- */
$comWhere = ['1=1'];
if ($judgeF) $comWhere[] = "c.judge_id = $judgeF";
if ($contF)  $comWhere[] = "c.contestant_id = $contF";
$comWhereSql = implode(' AND ', $comWhere);

$comments = $db->query("
  SELECT c.id, c.comment_text, c.created_at,
         j.full_name AS judge_name,
         con.contestant_number, con.full_name AS contestant_name
  FROM comments c
  JOIN judges j ON j.id = c.judge_id
  JOIN contestants con ON con.id = c.contestant_id
  WHERE $comWhereSql
  ORDER BY c.created_at DESC
");
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Scores & Comments - Admin</title>
  <link rel="stylesheet" href="../Style/style.css">
  <style>
    .admin-tabs{display:flex;gap:10px;margin-bottom:20px}
    .admin-tabs a{padding:8px 16px;background:var(--surface);border:2px solid var(--border-color);border-radius:8px;text-decoration:none;color:var(--text-primary);font-weight:600}
    .admin-tabs a.active{background:var(--primary-color);color:#fff;border-color:var(--primary-color)}
    .filter-bar{display:flex;gap:12px;margin-bottom:15px;flex-wrap:wrap}
    .filter-bar select{padding:8px 12px;border:2px solid var(--border-color);border-radius:6px}
    table{width:100%;border-collapse:separate;border-spacing:0;margin-top:15px}
    th,td{padding:10px 12px;border-bottom:1px solid var(--border-color)}
    th{background:var(--background);font-weight:600;font-size:.875rem;text-transform:uppercase;letter-spacing:.5px}
    .btn-danger{padding:4px 10px;background:var(--error-color);color:#fff;border:none;border-radius:6px;font-size:.8125rem;cursor:pointer}
  </style>
</head>
<body>
<?php include __DIR__ . '/../Includes/navbar.php'; ?>
<div class="container">
  <div class="page-header">
    <h1>🔧 Scores & Comments (Admin)</h1>
    <p>Browse / delete any score or comment</p>
  </div>
  <!-- tabs -->
  <div class="admin-tabs">
    <a href="?tab=scores" class="<?= (!isset($_GET['tab']) || $_GET['tab']==='scores')?'active':'' ?>">Scores</a>
    <a href="?tab=comments" class="<?= ($_GET['tab']==='comments')?'active':'' ?>">Comments</a>
  </div>
  <!-- filters -->
  <form method="GET" class="filter-bar">
    <select name="judge" onchange="this.form.submit()">
      <option value="">All Judges</option>
      <?php while($j=$judges->fetch_assoc()): ?>
        <option value="<?=$j['id']?>" <?=($judgeF==$j['id'])?'selected':''?>><?=htmlspecialchars($j['full_name'])?></option>
      <?php endwhile; ?>
    </select>
<select name="contestant" onchange="this.form.submit()">
  <option value="">All Contestants</option>
  <?php while($c=$conts->fetch_assoc()): ?>
    <option value="<?=$c['id']?>" <?=($contF==$c['id'])?'selected':''?>>#<?=$c['contestant_number']?> - <?=htmlspecialchars($c['full_name'])?></option>
  <?php endwhile; ?>
</select>

<?php if(!isset($_GET['tab']) || $_GET['tab']==='scores'): ?>
<select name="category" onchange="this.form.submit()">
  <option value="">All Categories</option>
  <?php while($ca=$cats->fetch_assoc()): ?>
    <option value="<?=$ca['id']?>" <?=($catF==$ca['id'])?'selected':''?>><?=htmlspecialchars($ca['category_name'])?></option>
  <?php endwhile; ?>
</select>
<?php endif; ?>

<?php if($judgeF||$contF||$catF): ?>
  <a href="ScoresComments.php?tab=<?=htmlspecialchars($_GET['tab']??'scores')?>" class="btn-secondary">Clear</a>
<?php endif; ?></form>
  <!-- scores table -->
  <?php if(!isset($_GET['tab']) || $_GET['tab']==='scores'): ?>
    <div class="card">
  <h2>Scores (<?=$scores->num_rows?>)</h2>
  <?php if($scores->num_rows): ?>
  <table>
    <thead>
      <tr>
        <th>Judge</th><th>Contestant</th><th>Category</th><th>Score</th><th>Date</th><th></th>
      </tr>
    </thead>
    <tbody>
      <?php while($s=$scores->fetch_assoc()): ?>
      <tr>
        <td><?=htmlspecialchars($s['judge_name'])?></td>
        <td>#<?=$s['contestant_number']?> - <?=htmlspecialchars($s['contestant_name'])?></td>
        <td><?=htmlspecialchars($s['category_name'])?></td>
        <td><?=$s['score']?>/<?=$s['max_score']?></td>
        <td><?=date('M d, Y H:i',strtotime($s['scored_at']))?></td>
        <td>
          <form method="POST" onsubmit="return confirm('Delete this score?');">
            <input type="hidden" name="score_id" value="<?=$s['id']?>">
            <button class="btn-danger" name="delete_score">Delete</button>
          </form>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <?php else: ?>
    <p class="empty-state">No scores for current filters.</p>
  <?php endif; ?>
</div>
<?php endif; ?>
  <!-- comments table -->
  <?php if($_GET['tab']==='comments'): ?>
    <div class="card">
  <h2>Comments (<?=$comments->num_rows?>)</h2>
  <?php if($comments->num_rows): ?>
  <table>
    <thead>
      <tr>
        <th>Judge</th><th>Contestant</th><th>Comment</th><th>Date</th><th></th>
      </tr>
    </thead>
    <tbody>
      <?php while($c=$comments->fetch_assoc()): ?>
      <tr>
        <td><?=htmlspecialchars($c['judge_name'])?></td>
        <td>#<?=$c['contestant_number']?> - <?=htmlspecialchars($c['contestant_name'])?></td>
        <td style="white-space:pre-wrap"><?=htmlspecialchars($c['comment_text'])?></td>
        <td><?=date('M d, Y H:i',strtotime($c['created_at']))?></td>
        <td>
          <form method="POST" onsubmit="return confirm('Delete this comment?');">
            <input type="hidden" name="comment_id" value="<?=$c['id']?>">
            <button class="btn-danger" name="delete_comment">Delete</button>
          </form>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <?php else: ?>
    <p class="empty-state">No comments for current filters.</p>
  <?php endif; ?>
</div>
 <?php endif; ?>
</div>
</body>
</html>